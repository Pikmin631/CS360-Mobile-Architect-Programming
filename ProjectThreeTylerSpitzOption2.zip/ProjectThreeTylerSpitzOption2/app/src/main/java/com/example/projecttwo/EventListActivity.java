package com.example.projecttwo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class EventListActivity extends AppCompatActivity {

    private DataBaseHelper dbHelper;
    private GridLayout eventGrid;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        userId = getIntent().getIntExtra("USER_ID", -1);
        dbHelper = new DataBaseHelper(this);
        eventGrid = findViewById(R.id.eventGrid);

        FloatingActionButton addEventFab = findViewById(R.id.addEventFab);
        addEventFab.setOnClickListener(v -> showAddEditDialog(null));

        ImageButton smsSettingsButton = findViewById(R.id.smsSettingsButton); // sets up SMS enable button
        smsSettingsButton.setOnClickListener(v -> checkOrRequestSmsPermission());

        ImageButton logoutButton = findViewById(R.id.logoutButton);// sets up logout button
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventListActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        refreshGrid();
    }

    private void refreshGrid() {// after CRUD refreshes the grid to organize all events to chronological order by date
        eventGrid.removeAllViews();
        List<Event> events = dbHelper.getAllEvents(userId); // pass userId here

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy h:mm a", Locale.US);
        Collections.sort(events, (e1, e2) -> { //sorts event by date
            try {
                Date d1 = sdf.parse(e1.getEventDate() + " " + e1.getEventTime());
                Date d2 = sdf.parse(e2.getEventDate() + " " + e2.getEventTime());
                return d1.compareTo(d2);
            } catch (ParseException e) {
                return 0;
            }
        });

        for (Event event : events) {
            View card = getLayoutInflater().inflate(R.layout.item_event_card, eventGrid, false);

            TextView titleView = card.findViewById(R.id.eventTitle);
            TextView dateView = card.findViewById(R.id.eventDate);
            TextView timeView = card.findViewById(R.id.eventTime);
            TextView descView = card.findViewById(R.id.eventDescription);
            FloatingActionButton editFab = card.findViewById(R.id.deleteEventFab);

            titleView.setText(event.getEventName());
            dateView.setText(event.getEventDate());
            timeView.setText(event.getEventTime());
            descView.setText(event.getNotes());

            editFab.setOnClickListener(v -> showAddEditDialog(event));

            eventGrid.addView(card);
        }
    }
    private void checkOrRequestSmsPermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS notifications are enabled. Opening settings...", Toast.LENGTH_SHORT).show();

        }

        // If Android will still show the normal request popup, ask directly
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 101);
        } else {
            // Settings screen can re-enable it now, so send them there directly
            Toast.makeText(this, "Enable SMS permission in app settings.", Toast.LENGTH_LONG).show();

        }
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }
    private void showAddEditDialog(Event event) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 24, 48, 24);

        EditText nameInput = new EditText(this);
        nameInput.setHint("Event name");

        EditText dateInput = new EditText(this);
        dateInput.setHint("Event date");
        dateInput.setFocusable(false);
        dateInput.setClickable(true);

        EditText timeInput = new EditText(this);
        timeInput.setHint("Event time");
        timeInput.setFocusable(false);
        timeInput.setClickable(true);

        EditText descInput = new EditText(this);
        descInput.setHint("Description (optional)");

        if (event != null) {
            nameInput.setText(event.getEventName());
            dateInput.setText(event.getEventDate());
            timeInput.setText(event.getEventTime());
            descInput.setText(event.getNotes());
        }

        dateInput.setOnClickListener(v -> showDatePicker(dateInput));
        timeInput.setOnClickListener(v -> showTimePicker(timeInput));

        layout.addView(nameInput);
        layout.addView(dateInput);
        layout.addView(timeInput);
        layout.addView(descInput);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(event == null ? "Add Event" : "Edit Event")
                .setView(layout)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null);

        // Only show Delete when editing an existing event
        if (event != null) {
            builder.setNeutralButton("Delete", null); // listener set manually below
        }

        AlertDialog dialog = builder.create();

        dialog.setOnShowListener(d -> {
            Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            saveButton.setOnClickListener(v -> {
                String name = nameInput.getText().toString().trim();
                String date = dateInput.getText().toString().trim();
                String time = timeInput.getText().toString().trim();
                String notes = descInput.getText().toString().trim();

                boolean valid = true;
                int red = getResources().getColor(android.R.color.holo_red_light);
                int gray = getResources().getColor(android.R.color.darker_gray);

                //if user tries to save event before entering a name, date, or time
                if (name.isEmpty()) {
                    nameInput.setHintTextColor(red);
                    nameInput.setHint("Event name required");
                    valid = false;
                } else {
                    nameInput.setHintTextColor(gray);
                }

                if (date.isEmpty()) {
                    dateInput.setHintTextColor(red);
                    dateInput.setHint("Event date required");
                    valid = false;
                } else {
                    dateInput.setHintTextColor(gray);
                }

                if (time.isEmpty()) {
                    timeInput.setHintTextColor(red);
                    timeInput.setHint("Event time required");
                    valid = false;
                } else {
                    timeInput.setHintTextColor(gray);
                }

                if (!valid) return;

                if (event == null) {
                    dbHelper.addEvent(userId, name, date, time, notes);
                } else {
                    dbHelper.updateEvent(event.getId(), name, date, time, notes);
                }
                refreshGrid();
                dialog.dismiss();
            });

            // confirmation message if deleting an event with the option to cancel
            if (event != null) {
                Button deleteButton = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
                deleteButton.setOnClickListener(v -> {
                    new AlertDialog.Builder(this)
                            .setTitle("Delete Event")
                            .setMessage("Delete \"" + event.getEventName() + "\"?")
                            .setPositiveButton("Delete", (confirmDialog, which) -> {
                                dbHelper.deleteEvent(event.getId());
                                refreshGrid();
                                dialog.dismiss();
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                });
            }
        });

        dialog.show();
    }

    // Calendar picker: displays a calendar to select a date for the event
    private void showDatePicker(EditText dateInput) {
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        CalendarView calendarView = new CalendarView(this);
        calendarView.setMinDate(today.getTimeInMillis()); // disables past dates so only a valid date can be selected

        AlertDialog datePickerDialog = new AlertDialog.Builder(this)
                .setTitle("Select Date")
                .setView(calendarView)
                .setNegativeButton("Cancel", null)
                .create();
        //adds selected date to event card
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            String formatted = String.format(Locale.US, "%02d/%02d/%d", month + 1, dayOfMonth, year);
            dateInput.setText(formatted);
            dateInput.setHintTextColor(getResources().getColor(android.R.color.darker_gray));
            datePickerDialog.dismiss();
        });

        datePickerDialog.show();
    }

    // scrollable time picker
    private void showTimePicker(EditText timeInput) {
        LinearLayout pickerLayout = new LinearLayout(this);
        pickerLayout.setOrientation(LinearLayout.HORIZONTAL);
        pickerLayout.setGravity(Gravity.CENTER);

        NumberPicker hourPicker = new NumberPicker(this);
        hourPicker.setMinValue(1);
        hourPicker.setMaxValue(12);

        NumberPicker minutePicker = new NumberPicker(this);
        minutePicker.setMinValue(0);
        minutePicker.setMaxValue(59);
        minutePicker.setFormatter(value -> String.format(Locale.US, "%02d", value));

        NumberPicker amPmPicker = new NumberPicker(this);
        amPmPicker.setMinValue(0);
        amPmPicker.setMaxValue(1);
        amPmPicker.setDisplayedValues(new String[]{"AM", "PM"});

        // prefills wheels if editing an existing time
        String existing = timeInput.getText().toString().trim();
        if (!existing.isEmpty()) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat("h:mm a", Locale.US);
                Calendar cal = Calendar.getInstance();
                cal.setTime(parser.parse(existing));
                int hour24 = cal.get(Calendar.HOUR_OF_DAY);
                hourPicker.setValue(hour24 % 12 == 0 ? 12 : hour24 % 12);
                minutePicker.setValue(cal.get(Calendar.MINUTE));
                amPmPicker.setValue(hour24 >= 12 ? 1 : 0);
            } catch (ParseException ignored) { }
        }

        pickerLayout.addView(hourPicker);
        pickerLayout.addView(minutePicker);
        pickerLayout.addView(amPmPicker);

        new AlertDialog.Builder(this)
                .setTitle("Select Time")
                .setView(pickerLayout)
                .setPositiveButton("Set", (dialog, which) -> {
                    String formatted = String.format(Locale.US, "%d:%02d %s",
                            hourPicker.getValue(), minutePicker.getValue(),
                            amPmPicker.getDisplayedValues()[amPmPicker.getValue()]);
                    timeInput.setText(formatted);
                    timeInput.setHintTextColor(getResources().getColor(android.R.color.darker_gray));
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}