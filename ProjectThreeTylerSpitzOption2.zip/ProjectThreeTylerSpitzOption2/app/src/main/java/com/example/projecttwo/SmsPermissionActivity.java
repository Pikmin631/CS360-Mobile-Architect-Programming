package com.example.projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class SmsPermissionActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private int userId;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        userId = getIntent().getIntExtra("USER_ID", -1);

        prefs = getSharedPreferences("EventTrackerPrefs", MODE_PRIVATE);

        findViewById(R.id.allowButton).setOnClickListener(v ->
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS));

        findViewById(R.id.skipButton).setOnClickListener(v -> markAnsweredAndContinue());
    }

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                //stores user answer so that sms notification is only asked once.
                if (isGranted) {
                    SmsHelper.sendSms(this, "You have successfully opted to enable notifications via Event Tracker.");
                }
                markAnsweredAndContinue();
            });
    private void markAnsweredAndContinue() {//saves user answer so that it only asks the first time for account creation
        prefs.edit().putBoolean("sms_permission_asked", true).apply();
        Intent intent = new Intent(SmsPermissionActivity.this, EventListActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }
}
