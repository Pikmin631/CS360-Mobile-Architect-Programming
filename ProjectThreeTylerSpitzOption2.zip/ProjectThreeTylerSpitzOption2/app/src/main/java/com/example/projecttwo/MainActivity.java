package com.example.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton;
    private TextView errorText;
    private DataBaseHelper dbHelper;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        errorText = findViewById(R.id.errorText);

        dbHelper = new DataBaseHelper(this);
        prefs = getSharedPreferences("EventTrackerPrefs", MODE_PRIVATE);
        errorText.setVisibility(View.GONE);

        // prefills the username if a username was previously used
        String lastUsername = prefs.getString("last_username", "");
        if (!lastUsername.isEmpty()) {
            usernameEditText.setText(lastUsername);
            passwordEditText.requestFocus();
        }

        loginButton.setOnClickListener(v -> attemptLogin());
        createAccountButton.setOnClickListener(v -> attemptCreateAccount());
    }

    private void attemptLogin() { // given username and password are checked within the dataBaseHelper
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            showError("Please enter a username and password.");
            return;
        }

        if (dbHelper.checkLogin(username, password)) {
            errorText.setVisibility(View.GONE);//initially hides errortext before checking validity of credentials
            prefs.edit().putString("last_username", username).apply();
            int userId = dbHelper.getUserId(username, password);

            boolean alreadyAsked = prefs.getBoolean("sms_permission_asked", false);
            Intent intent;
            if (alreadyAsked) { //checks if sms was already asked or not
                intent = new Intent(MainActivity.this, EventListActivity.class);
            } else {
                intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
            }
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        } else {
            showError("Invalid account/password, please try again"); // if invalid the error text is shown
        }
    }

    private void attemptCreateAccount() {// when creating, the database is checked for prexisting accounts
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            showError("Please enter a username and password.");
            return;
        }

        boolean created = dbHelper.createUser(username, password);
        if (created) { // validates a newly created account and logs in
            errorText.setVisibility(View.GONE);
            prefs.edit().putString("last_username", username).apply();
            int userId = dbHelper.getUserId(username, password);

            boolean alreadyAsked = prefs.getBoolean("sms_permission_asked", false);
            Intent intent;
            if (alreadyAsked) {
                intent = new Intent(MainActivity.this, EventListActivity.class);
            } else {
                intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
            }
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        } else {
            showError("That username is already taken.");
        }
    }

    private void showError(String message) {//takes any errors and displays a message to the user in red
        errorText.setText(message);
        errorText.setTextColor(getResources().getColor(android.R.color.holo_red_light));
        errorText.setVisibility(View.VISIBLE);
    }
}