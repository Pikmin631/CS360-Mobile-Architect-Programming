package com.example.projecttwo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;

public class SmsHelper {

    public static final String TEST_PHONE_NUMBER = "5554";

    public static void sendSms(Context context, String message) {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        SmsManager.getDefault().sendTextMessage(TEST_PHONE_NUMBER, null, message, null, null);
    }
}
